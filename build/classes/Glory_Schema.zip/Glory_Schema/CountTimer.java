package Glory_Schema;

import java.util.Timer;

public class CountTimer {

    static int interval;
    static Timer timer;
    //private int sec;
    GamePlay gamePlay;

 public CountTimer (){  
         //constructor to set countdown time
 };

    public void StartTimer(){

 }

   
}
