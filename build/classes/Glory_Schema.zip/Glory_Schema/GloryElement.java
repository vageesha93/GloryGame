
package Glory_Schema;


/**
 * 
 * main class ..  GloryElement class 
 */
public class GloryElement {
    

protected int bonuses;  //some of the letter values of the returned English word and their bonunsvor rewards;

}
