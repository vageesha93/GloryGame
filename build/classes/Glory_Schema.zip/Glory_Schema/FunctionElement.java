
package Glory_Schema;


import java.util.ArrayList;
import java.util.List;


public class FunctionElement extends GloryElement{
    
    private final List<Character> wordchar  = new ArrayList<>();  //store random generated word as characters
    
      private final List<Character> letters  = new ArrayList<>();  //store user inset word(input result) as characters



    public String getThreeinitial(){
        //method to get 3initial letters
        
        return null;
  
    }


      /*
      getrandomletter method user for generate three initial letters
      */
    public char getrandomletter(){
        char letter = 0;
    
        return letter;
    }
    
    /*
    put  random generated word into characters
    */
    public void putintochar(String word){
      
    }
    
    /*
    put the user insert word into character
    */
     public void putintoletters(String word){
 
    }
    
    /*
     calculate the bouns and letter value
     */
    public void calbouns(){
       
        }

        
    
    }

    
    

