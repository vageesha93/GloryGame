
package Glory_Schema;


/*
This consists of defining the punishment 
*/
public class PenaltyElement extends GloryElement{
    
    public static boolean IsGive=false;
   public static int CountDownTime=60;
    
    
}
